<?php 
include_once '../classes/autoload.php';

//Login::checkAuth();

$usuarioDao = new UsuarioDao();
$lista = $usuarioDao->select();
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Lista de Usuarios </title>

</head>

<body>
    
                                <table class="table table-striped table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Nome</th>
                                            <th>E-mail</th>
                                            <th>Ação</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                       <?php foreach($lista as $usario): ?>
                                        
                                        <tr>
                                            <td><?php echo $usario->getId(); ?></td>
                                            <td><?php echo $usario->getNome(); ?></td>
                                            <td><?php echo $usario->getEmail(); ?></td>
                                            <td>
                                            <button type="button" onclick="window.location='usuario-edita.php?id=<?php echo $usario->getId(); ?>';" class="btn btn-outline btn-primary    
">Editar</button>
<button type="button" onclick="confirm('Deseja exclir este registro?') ? window.location='usuario-deleta-ok.php?id=<?php echo $usario->getId(); ?>' : stop = false;" class="btn btn-outline btn-danger">Deletar</button>
                                            </td>
                                        </tr>
                                       <?php endforeach; ?> 
                                        
                                    </tbody>
                                </table>
                          
</body>

</html>