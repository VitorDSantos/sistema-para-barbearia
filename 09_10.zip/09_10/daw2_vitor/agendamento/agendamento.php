<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Login</title>
<link rel="stylesheet" type="text/css" href="assets/css/agenda.css">
<link rel="icon" type="imagem/jpg" href="assets/imagens/logop.png"/>
</head>
<body>
<div class="div">
	<div class="div2"><img src="assets/imagens/logop.png"></div>
	<div class="div3"><h1>Fazer Agendamento</h1></div>
</div>
	<div class="loginbox" style="background-color:white;">
	<img src="assets/imagens/user.jpg" class="avatar">
		<h1>Faça o Cadastro</h1><br>
		<form role="form" action="agendamento-.html" method="POST">
			<p>Nome Completo:</p>
				<input type="text" id="nome"  name="nome" placeholder="Acrecentar Nome" required>
			<p>Escolher serviços:</p>
				<input type="text" id="nome"  name="servico" placeholder="Serviço" required>
			<p>Escolher Atendente:</p>
				<input type="text" id="nome"  name="atendente" placeholder="Atendente(Opcional)" >
			<p>Deixar algum Comentário:</p>
				<input type="textarea" id="nome"  name="comentario" placeholder="Comentário(Opcinal)" >
				
			<p>Data:</p>
				<input type="date" id="data"  name="data" placeholder="Acrecentar Data" required>
			<a href="barber.html">Voltar</a><br>
			<a href="admin/calendario_agenda.html">Ver Cronograma de Horários</a>
			<input type="submit" placeholder="Enviar" name="Cadastrar">
		</form>
		
	</div>
</body>
</html>